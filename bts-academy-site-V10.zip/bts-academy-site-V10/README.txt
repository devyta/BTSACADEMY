# BTS Academy — Promo Website

Cara pakai di Netlify:
1. Upload file `bts-academy-site.zip` ke Netlify (Drag & drop).
2. Untuk ganti gambar galeri/hero, edit `index.html` dan ubah URL gambar.
3. Logo ada di `assets/logo.png` (diambil dari lampiran Anda).
4. Form pendaftaran akan membuka WhatsApp `+62 812-9327-9819` dengan pesan terformat.

Struktur:
- index.html
- styles.css
- script.js
- assets/logo.png
